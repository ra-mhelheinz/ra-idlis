<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::match(['get', 'post'], '/', 'loginController@login');

Route::get('/home', 'layoutController@home');
Route::get('/apply', 'layoutController@apply');
Route::get('/evaluate', 'layoutController@evaluate');

Route::get('/inspection', 'layoutController@inspection');
Route::get('/inspection2', 'layoutController@inspection2');
Route::get('/inspection3', 'layoutController@inspection3');
Route::get('/issuance', 'layoutController@issuance');
Route::get('/dashboard', 'layoutController@dashboard');
Route::get('/logout','layoutController@logout');

Route::get('/ph','ajaxController@index');
// Route::post('/ph/get_province','ajaxController@selectProvince');
Route::post('/ph/get_province', ['as'=>'select-province','uses'=>'ajaxController@selectProvince']);
Route::post('/ph/add_cm','ajaxController@addCM');
Route::view('/dashboard/evaluate/orderofpayment','template.orderofpayment');
Route::view('/dashboard/evaluate/orderofpayment2','template.orderofpayment2');
Route::view('/dashboard/evaluate/orderofpayment3','template.orderofpayment3');
Route::view('/dashboard/evaluate/orderofpayment4','template.orderofpayment4');
Route::view('/dashboard/evaluate/orderofpayment5','template.orderofpayment5');
Route::view('/evaluate2', 'template.evaluate2');
Route::get('/evaluate', 'layoutController@evaluate');
Route::get('/reancy', 'reancyController@index');
Route::view('/dashboard/evaluate/orderofpayment6','template.orderofpayment6');
Route::get('headashboard/loaccount','AdminController@view');

Route::view('/dashboard/evaluate', 'template.loevaluate');
Route::view('/dashboard/inspection', 'template.loinspection');
Route::view('/dashboard/inspection2', 'template.loinspection2');
Route::view('/dashboard/inspection3', 'template.loinspection3');
Route::view('/dashboard/loissuance', 'template.loissuance');
Route::view('/headashboard', 'template.headashboard');
Route::view('/orderofpaymentc', 'template.orderofpaymentc');
Route::match(['get', 'post'], '/employeelogin', 'loginController@employeelogin');
 ///// WITH MATCH
Route::match(['get', 'post'], '/register', 'layoutController@register');
 ///// ADD NEW
Route::post('/headashboard/addLO','AdminController@create_LO');

Route::post('/dashboard/deativate/{id}','layoutController@deactivate_LO');
Route::post('/headashboard/deleteLO/{id}','AdminController@destroy_LO');
Route::post('/headashboard/reactivateLO/{id}','AdminController@reactivate_LO');
///headashboard/reactivateLO/'.$user->id
Route::post('/logout2','layoutController@logout2');

Route::post('/dashboard/evaluate/orderofpayment/submit','layoutController@submitOP');