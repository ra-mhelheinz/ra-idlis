function region(){
	if(document.getElementById('regionSelector').selectedIndex < 1) {

	} else {
		alert(document.getElementById('regionSelector').options[document.getElementById('regionSelector').selectedIndex]);
	}
}