  @include('template.head')
  @include('template.dashnav')
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Dashboard</h1>
          </div>
          <div class="jumbotron">
          <h2>Licensing Process Status</h2>
          <div class="table-responsive">
            <table class="table" style="overflow-x: scroll;">
              <thead>
                <tr>
                  <th>Application #</th>
                  <th>Name of Facility</th>
                  <th>Status of Application</th>
                  <th>Evaluate</th>
                  <th>Order of Payment</th>
                  <th>Upload OR Copy</th>
                  <th>Recommended for Inspection</th>
                  <th>Date of inspection</th>
                  <th>Issuance Status: Approval/Disapproval</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>ABC Hospital</td>
                  <td>Initial</td>
                  <td><a href="{{asset('dashboard/evaluate')}}">Evaluate</a></td>
                  <td></td>
                   <td></td>
                    <td><a href="{{asset('dashboard/inspection')}}" style="color:green;">Yes</a></td>
                    <td>05/05/2018</td>
                    <td><a href="{{asset('dashboard/loissuance')}}" style="color:green;">Approved </a></td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>C.D Clinic</td>
                  <td>Renewal</td>
                  <td><a href="{{asset('dashboard/evaluate')}}">Evaluate</a></td>
                  <td></td>
                  <td></td>
                  <td style="color:red;">No</td>
                   <td></td>
                   <td style="color:red;">Disapproved</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Hospital H</td>
                  <td>Initial</td>
                  <td><a href="{{asset('dashboard/evaluate')}}">Evaluate</a></td>
                  <td></td>
                  <td></td>
                   <td style="color:red;">No</td>
                    <td></td>
                     <td style="color:red;">Disapproved</td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>libero</td>
                  <td>Renewal</td>
                  <td><a href="{{asset('dashboard/evaluate')}}">Evaluate</a></td>
                  <td></td>
                  <td></td>
                   <td style="color:red;">No</td>
                    <td></td>
                     <td style="color:red;">Disapproved</td>

                </tr>
                <tr>
                  <td>5</td>
                  <td>dapibus</td>
                  <td>Initial</td>
                  <td><a href="{{asset('dashboard/evaluate')}}">Evaluate</a></td>
                  <td></td>
                  <td></td>
                   <td style="color:red;">No</td>
                    <td></td>
                     <td style="color:red;">Disapproved</td>
                </tr>
              </tbody>
            </table>
          </div>
      </div>
        </main>
      </div>
    </div>
