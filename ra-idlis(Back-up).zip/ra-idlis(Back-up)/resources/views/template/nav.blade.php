@if (session()->exists('current_user'))


   
    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top" style="box-shadow: 0px 2px 4px rgba(0,0,0,0.2);" >
      <div class="container">
        <a class="navbar-brand" href="#">Welcome</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="{{asset('home')}}">Home
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="#">Services</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="#">About DOH</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contact</a>
            </li>
              <li class="nav-item dropdown">
             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="fas fa-user-circle"></span>&nbsp;  @foreach(Session::get('current_user') as $test)
      {{$test->authorized}}
      @endforeach
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">

          <a class="dropdown-item" href="{{asset('logout')}}">Logout</a>
        </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
   <nav aria-label="breadcrumb" class="container" >
  <ol class="breadcrumb" style="background-color: #fff !important;">
    <li class=""><a href="#">Home</a></li>
    	<li class="">&nbsp;&gt;&nbsp;</li>
    <li class=""><a href="#">Library</a></li>
    <li class="">&nbsp;&gt;&nbsp;</li>&nbsp;
    <li class=""><a href="#">Data</a></li>
  </ol>
</nav>
@else
<script>window.location.href = "{{asset('')}}";</script>
@endif  