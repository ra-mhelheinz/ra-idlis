<!DOCTYPE html>
<html lang="en">
<head>
	@include('template.head')
</head>
<body>
	@include('template.logo')
	<div class="container">
		<h1>Philippines</h1>
		<hr>
		<hr>
		<h3>Regions</h3>
		<form action="">
			<h4>Add New region</h4>
			@csrf
			<input class="input form-control" type="text" name="new_region" placeholder="Region Name">
			<button type="submit" class="btn btn-success">Save Region</button>
		</form>
		<hr>
		<h3>Provinces</h3>
		<form>
			<h4>Add New Province</h4>
			@csrf
			<label>Region :</label>
			<select class="form-control">
					<option value="0" />Select Region</option>
				@foreach ($regions as $region)
					<option value="{{$region->reg_id}}">{{$region->reg_name}}</option>
				@endforeach
					
			</select>
			<input class="input form-control" type="text" name="new_province" placeholder="Province Name">
			<button class="btn btn-success" type="submit">Save Province</button>
		</form>
		<hr>
		<h3>Cities and Municipalities</h3>
		<form method="POST" action="{{asset('/ph/add_cm')}}">
			<input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
			<h4>Add New City/Municipality</h4>
			<label>Region:</label>
			<select class="form-control" id="selectRegion4CM" name="regionCM">
				<option value="0">Select Region</option>
				@foreach ($regions as $region)
					<option value="{{$region->reg_id}}">{{$region->reg_name}}</option>
				@endforeach
			</select>
			<label>Province:</label>
			<select class="form-control" id="selectProvince4Cm" name="provinceCM">
				<option value="0">Select Province </option>
			</select>
			<input class="input form-control" type="text" name="new_cm"></input>
			<button class="btn btn-success" type="submit">Save City/Municipality</button>
		</form>
	</div>
</body>
<script type="text/javascript">
  $("#selectRegion4CM").change(function(){
      var region_id = $(this).val();
      var token = $("#csrf-token").val();
      $.ajax({
          url: " {{asset('/ph/get_province')}}",
          method: 'POST',
          data: {reg_id:region_id, _token:token},
          success: function(data) {
          	var x = data.provinces;
          	$('#selectProvince4Cm').empty();
          	for (var i = 0; i < x.length; i++) {
          		$('#selectProvince4Cm').append(
          				'<option value="'+x[i].pro_id+'">'+x[i].pro_name +'</option>'
          			);
          	}
          }
      });
  });
</script>