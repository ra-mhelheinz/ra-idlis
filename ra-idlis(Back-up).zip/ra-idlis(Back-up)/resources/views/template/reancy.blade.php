@include('template.head')
@include('template.dashnav')
<?php $var = array(); $name = array(); $style = array(); $ctnt = array(); $rowind = array(); $colind = array(); $ctntstl = array(); ?>

@foreach($hdr as $data)
  <?php array_push($var, $data->tbl_colind); array_push($style, $data->tbl_stl); array_push($name, $data->tbl_colnm); ?>
@endforeach

@foreach($cnt as $data)
  <?php array_push($ctnt, $data->tbl_colcont); array_push($rowind, $data->tbl_rowind); array_push($colind, $data->tbl_colind); array_push($ctntstl, $data->tbl_stl); ?>
@endforeach

<div class="row container-fluid" style="margin-top: 10px;">
	<div class="col-sm-2"></div>
	<div class="col-sm-10">
		  <div class="card" style="margin: 0 0 5em 0;">
        <div class="card-header bg-white font-weight-bold">
          <table table border="1" class="text-center" style="width: 100%;">
          </table>
          <script type="text/javascript">
            var tbl = document.getElementsByTagName("table")[0];
            var row = tbl.insertRow(0);
            var c0 = row.insertCell(0);
            var c1 = row.insertCell(1);
            var c2 = row.insertCell(2);
            var c3 = row.insertCell(3);
            var c4 = row.insertCell(4);
            @for($i = 0; $i < count($var); $i++)
              c{{ $var[$i] }}.setAttribute("style", "{{ $style[$i] }}");
              c{{ $var[$i] }}.innerHTML = "{{ $name[$i] }}";
            @endfor
          </script>
          <script type="text/javascript">
            var tbl = document.getElementsByTagName("table")[0];
            <?php $diff = 0; ?>
            @for($j = 0; $j < count($rowind); $j++)
              @if($diff != $rowind[$j])
                <?php $diff = $rowind[$j]; ?>
                var row1 = tbl.insertRow({{$rowind[$j]}});
                var cc0 = row1.insertCell(0);
                var cc1 = row1.insertCell(1);
                var cc2 = row1.insertCell(2);
                var cc3 = row1.insertCell(3);
                var cc4 = row1.insertCell(4);
                @for($i = 0; $i < count($colind); $i++)
                  cc{{$colind[$i]}}.setAttribute("style", "{{ $ctntstl[$i] }}");
                  @if($ctnt[$i] == "checkbox")
                    cc{{$colind[$i]}}.innerHTML = '<input type="checkbox" name="" onchange="Subtotal(200,\'regFree\')" id="regFree" style="width: 2rem;height: 1rem;">';
                  @else
                    cc{{$colind[$i]}}.innerHTML = "{{$ctnt[$i]}}";
                  @endif
                @endfor
              @endif
            @endfor
          </script>
          <script type="text/javascript">
          </script>
        </div>
      </div>
	</div>	
</div>