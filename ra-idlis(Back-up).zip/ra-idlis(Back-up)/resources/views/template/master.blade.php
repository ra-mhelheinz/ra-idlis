<!DOCTYPE html>
<html lang="en">
<head>
	@include('template.head')
</head>
<body>
	@include('template.nav')
	@yield('content')
	@include('template.footer')
</body>