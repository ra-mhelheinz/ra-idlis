@if (session()->exists('current_employee'))
@else
<script>window.location.href = "{{asset('/employeelogin')}}";</script>
@endif
 @include('template.head')
    <link rel="stylesheet" type="text/css" href="{{asset('/ra-idlis/public/css/dashboard.css')}}">
        <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Head, HFRLEB</a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="{{asset('/logout2')}}" onclick="event.preventDefault();document.getElementById('employeeLogout').submit();">Sign out</a>
          <form id="employeeLogout" action="{{asset('/logout2')}}" method="POST" hidden>
            @csrf
          </form>
        </li>
      </ul>
    </nav>
      <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="{{asset('/headashboard')}}">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Licensing Officer</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#"  data-toggle="modal" data-target="#myModal">
                  <span data-feather="file-text"></span>
                  Add Account
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" >
                  <span data-feather="file-text"></span>
                 View LO Accounts
                </a>
              </li>
            </ul>
          </div>
        </nav>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3">
            <h1 class="h2">Dashboard Licensing Officer Accounts</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <!-- <button class="btn btn-sm btn-outline-secondary">Share</button> -->
                <!-- <button class="btn btn-sm btn-outline-secondary">Export</button> -->
              </div>
              <!-- <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
              </button> -->
            </div>
          </div>
          <div class="table-responsive">
            <table class="table" style="overflow-x: scroll;" >
              <thead>
                <tr>
                  <th style="width: 50%">Name</th>
                  <th style="width: 15%">Position</th>
                  <th style="width: 10%">Status</th>
                  <th style="width: 25%">Options</th>
                </tr>
              </thead>
              <tbody>
                  <!-- <tr>
                    <td></td>
                    <td></td>
                    <td></td> -->
                    <!-- <td><a href=""><button class="btn btn-danger">Delete</button></a><a href=""><button class="btn btn-primary">View Details</button></a></td> -->
                 <!--  </tr> -->
                  @foreach ($users as $user)
                      <?php 
                        
                      ?>
                      <tr>
                        <td scope="row">{{$user->fname . ' '.$user->lname}}</td>
                        <td>{{$user->position}}</td>
                        <td>
                          @if ($user->login == '1' )
                          <font style="color:green">Active</font>
                          @else
                          <font style="color:red">Deactived</font>
                          @endif

                        </td>
                        <td>
                          <div class="row">
                            <a href="" data-toggle="modal" data-target="#ViewModal{{$user->id}}"><button class="btn btn-primary" title="View Account">&nbsp;<i class="fa fa-eye"></i>&nbsp;</button></a>&nbsp;
                            @if ($user->login == '1' )
                              <form onsubmit="return confirm('Are you sure you want to deactivate {{$user->fname . ' '.$user->lname}} ?')"action="{{asset('headashboard/deleteLO/'.$user->id)}}" method="POST">
                                 {{ csrf_field() }}
                                 {{-- @method('delete') --}}
                              <a href=""><button class="btn btn-danger" title="Deactivate Account">&nbsp;<i class="fa fa-toggle-off"></i>&nbsp;</button></a>
                            </form> 
                            @else
                            <form onsubmit="return confirm('Are you sure you want to reativate {{$user->fname . ' '.$user->lname}} ?')"action="{{asset('headashboard/reactivateLO/'.$user->id)}}" method="POST">
                               {{ csrf_field() }}
                               {{-- @method('delete') --}}
                            <a href=""><button class="btn btn-success" title="Reactivate Account">&nbsp;<i class="fa fa-toggle-on"></i>&nbsp;</button></a>
                          </form> 
                          @endif
                              
                          </div>
                        </td>
                      </tr>
                  @endforeach
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
 <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="border-radius: 0px;border: none;">
      <div class="modal-body text-justify" style=" background-color: #272b30;
    color: white;">
        <h5 class="modal-title text-center"><strong>Licensing Officer (LO) Registration</strong></h5>
        <hr>
        <div class="container">
          <form class="row" action="{{asset('headashboard/addLO')}}" method="POST">
            {{ csrf_field() }}
            <div class="col-sm-4">First Name:</div>
            <div class="col-sm-8">
            <input type="text" name="fname" class="form-control"  style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4" >Middle Name:</div>
            <div class="col-sm-8">
            <input type="text" name="mname" class="form-control" style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4"">Last Name:</div>
            <div class="col-sm-8">
            <input type="text" name="lname" class="form-control"  style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4"">Position:</div>
            <div class="col-sm-8">
            <select class="form-control" name="pos" id="pos_val" style="margin:0 0 .8em 0;" onchange="getOthers();">
            <option hidden></option>  
            <option>Licensing Officer I</option>  
            <option>Licensing Officer II</option>  
            <option>Licesing Officer III</option> 
            <option>Medical Officer V</option> 
            <option>Medical Officer IV</option> 
            <option>Medical Officer III</option> 
            <option>Dentist IV</option> 
            <option>Dentist IV</option> 
            <option>Dentist III</option> 
            <option>Dentist II</option> 
            <option>Others</option>
            </select>
            </div>
            <div class="col-sm-4 SH_Others"  style="display:none;"></div>  
            <div class="col-sm-8 SH_Others" style="display: none">
                <input type="name" name="OthersInput" id="OthersInputted" placeholder="Others" class="form-control" style="margin:0 0 .8em 0;" >
            </div>
            <div class="col-sm-4"">Email Address:</div>
            <div class="col-sm-8">
            <input type="email" name="email" class="form-control"  style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4"">Contact No:</div>
            <div class="col-sm-4">
            <input type="text" name="t_num" class="form-control" placeholder="Tel No." style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4">
            <input type="text" name="c_num" class="form-control" placeholder="Cel No." style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4">
              Username:
            </div>
            <div class="col-sm-8">
              <input type="text" name="uname" class="form-control" style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-4">
              Password:
            </div>
            <div class="col-sm-8">
              <input type="password" name="pass" class="form-control" style="margin:0 0 .8em 0;" required>
            </div>
            <div class="col-sm-12">
              <button type="submit" class="btn btn-outline-success form-control" style="border-radius:0;"><span class="fa fa-sign-up"></span>Add New Licensing Officer</button>
            </div> 
          </form>
       </div>
      </div>
    </div>
  </div>
</div>
@foreach($users as $user)
 <div class="modal fade" id="ViewModal{{$user->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="border-radius: 0px;border: none;">
      <div class="modal-body text-justify" style=" background-color: #272b30;
    color: white;">
        <h5 class="modal-title text-center"><strong>Licensing Officer (LO)</strong></h5>
        <hr>
        <div class="container">
        	<div class="row">
        		
        		<div class="col-sm-4">
        			<label>Full Name:</label>
        		</div>
        		<div class="col-sm-8">
        			<label>{{$user->fname . ' '. $user->mname . ' ' . $user->lname}}</label>
        		</div>	
        		<div class="col-sm-4">
        			<label>Position:</label>
        		</div>
        		<div class="col-sm-8">
        			<label>{{$user->position}}</label>
        		</div>
        		<div class="col-sm-4">
        			<label>Email Address:</label>
        		</div>
        		<div class="col-sm-8">
        			<label>{{$user->email}}</label>
        		</div>
        		<div class="col-sm-4">
        			<label>Contact No:</label>
        		</div>
        		<div class="col-sm-4">
        			<label>{{$user->t_phone}}</label>
        		</div>
        		<div class="col-sm-4">
        			<label>{{$user->c_phone}}</label>
        		</div>
        		
        	</div>
       </div>
      </div>
    </div>
  </div>
</div>
@endforeach
<script type="text/javascript">
    function getOthers(){
      var selectedId =  $('#pos_val').children(':selected').val();
      if (selectedId == "Others") {
        $('.SH_Others').show();
      } else {
         $('.SH_Others').hide();
      }
    }
</script>