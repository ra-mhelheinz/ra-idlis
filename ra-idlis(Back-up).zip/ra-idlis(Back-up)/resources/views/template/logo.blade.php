<div style="background: url('{{asset('/ra-idlis/public/color.png')}}') no-repeat;
    background-size: 100% auto; box-shadow: 0px 2px 4px rgba(0,0,0,0.2);">
<div class="container" >
  <div class="row">
    <div class="col-md-8">
      <img src="{{asset('/ra-idlis/public/DOH.png')}}" style="padding: 8px 8px 8px 0px;">
    </div>
    <div class="col-md-4"></div>
  </div>
</div>
</div>