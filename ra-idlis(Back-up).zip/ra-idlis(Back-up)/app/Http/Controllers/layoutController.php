<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Hash;
class layoutController extends Controller
{
    public function submitOP(){
      return 'TEST';
    }
   public function home(){
   	return view('template.landingpage');
   }
   public function apply(){
   	return view('template.apply');
   }
   public function evaluate(){
   	return view('template.evaluate');
   }
   public function inspection(){
   	return view('template.inspection');
   }
   public function inspection2(){
    return view('template.inspection2');
  }
   public function inspection3(){
    return view('template.inspection3');
   }
      public function loissuance(){
    return view('template.loissuance');
   }
    public function issuance(){
   	return view('template.issuance');
   }
    public function dashboard(){
      return view('template.dashboard');
   }
    public function logout(){
      session()->flush();
      // session()->forget('current_user');
      session()->flash('logout_notif','Successfully Logout');
      return view('template.landingpage');
    }
    public function logout2(){
      session()->flush();
      // session()->forget('current_employee');
      session()->flash('dohUser_logout','Successfully Logout');
      return redirect('/employeelogin');
    }

    public function getProv(Request $request){
      
    }
  public function deactivate_LO($id){
    DB::table('users')
            ->where('id',$id)
            ->update(['login' => 0]);
    session()->flash('dohUser_login','Account Deactivated');            
    return redirect('/employeelogin');
  }
   public function register(Request $request){
      if ($request->isMethod('get')) {
          $regions = DB::table('region')->get();
          return view('template.register', ['regions' => $regions]);
      }
      if ($request->isMethod('post')) {
          
          $data['facility_name'] = $request->input('facility_name');
          $data['region'] = $request->input('region');
          $data['province'] = $request->input('province');
          $data['brgy'] = $request->input('brgy');
          $data['street'] = $request->input('street');
          $data['city_muni'] = $request->input('city_muni');
          $data['zip'] = $request->input('zipcode');
          $data['authorized'] = $request->input('auth_name');
          $data['uname'] = $request->input('uname');
          $data['pass'] = Hash::make($request->input('pass2'));
          $data['email'] = $request->input('email');
          $data['contact_p'] = $request->input('contact_p');
          DB::table('accounts')->insert(
            ['facility_name' => $data['facility_name'],
            'region' => $data['region'],
            'province' => $data['province'],
            'brgy' => $data['brgy'],
            'street' => $data['street'],
            'city_mun' => $data['city_muni'],
            'zip' => $data['zip'],
            'authorized' => $data['authorized'],
            'username' => $data['uname'],
            'password' => $data['pass'],
            'email' => $data['email'],
            'contact_p' => $data['contact_p'],
            ]
        );
        session()->flash('reg_notif_success','Successfully Registered');
        return redirect('/');
      }
   }
}
