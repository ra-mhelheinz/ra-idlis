<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class loginController extends Controller
{
   public function login(Request $request){
   	if($request->isMethod('get')){
   		return view('template.login');
   	}
   	if($request->isMethod('post')){
   		$uname=$request->input('uname');
   		$pass= $request->input('pass');
         $pass = Hash::check('pass', $pass);
   		$data = DB::select('select * from accounts where username=? and password=? limit 1', [$uname, $pass]);
   		if (count($data)){
            session()->put('current_user',$data);
   			return redirect('/home');
   		}
         else{
            session()->flash('client_login','Invalid Username/Password');
            return back();
         }
   	}
   }
   public function employeelogin(Request $request){
      if ($request->isMethod('get')){
         return view('template.employeelogin');
      }
      if($request->ismethod('post')){
         $unamee=$request->input('uname');
         $passe=$request->input('pass');
          $passe=Hash::check('pass', $passe);
         $data = DB::select('select * from users where uname=? and pass=? limit 1', [$unamee,$passe]);
         if (count($data)){
            session()->put('current_employee',$data);
            $sample = session()->get('current_employee');
            foreach ($sample as $key => $value) {
               $loginstatus = $value->login;
            	$data2 = $value->position;
            	if ($loginstatus == 1 ) {
                  if ($data2 == 'Head') {
                     return redirect('/headashboard');
                  } else {
                     return redirect('/dashboard');
                  }
               } else {
                  session()->flush();
                  session()->flash('dohUser_login','Account Deactivated, Contact Office Head');
                  return back();
               }
            }
         }
         else{
            session()->flash('dohUser_login','Invalid Username/Password');
            return back();
         }
      }
   }
}
