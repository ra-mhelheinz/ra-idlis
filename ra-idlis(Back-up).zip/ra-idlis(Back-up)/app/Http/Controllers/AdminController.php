<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Hash;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view()
    {
        $users = DB::select("SELECT * FROM users WHERE position != 'Head'");
        return view('template.loaccount', ['users' => $users]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create_LO(Request $request)
    {

        $data['fname'] = $request->input('fname');
        $data['mname'] = $request->input('mname');
        $data['lname'] = $request->input('lname');
        $data['position'] = $request->input('pos');
        $data['email'] = $request->input('email');
        $data['t_phone'] = $request->input('t_num');
        $data['c_phone'] = $request->input('c_num');
        $data['uname'] = $request->input('uname');
        $data['pass'] = Hash::make($request->input('pass'));
        if ($data['position'] === "Others") {
           $data['position'] = $request->input('OthersInput');
        }
        DB::table('users')->insert(
            ['fname' => $data['fname'], 
            'mname' => $data['mname'],
            'lname' => $data['lname'],
            'position' => $data['position'],
            'email' => $data['email'],
            't_phone' => $data['t_phone'],
            'c_phone' => $data['c_phone'],
            'uname' => $data['uname'],
            'pass' =>$data['pass']
            ]
        );
        return back();
        

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy_LO($id)
    {
        // DB::table('users')->where('id',$id)->delete();
        DB::table('users')
            ->where('id',$id)
            ->update(['login' => 0]);
        return redirect('/headashboard/loaccount');
    }
    public function reactivate_LO($id){
        DB::table('users')
            ->where('id',$id)
            ->update(['login' => 1]);
        return redirect('/headashboard/loaccount');
    }
}
