<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class reancyController extends Controller
{
   public function index(){
      // return view('template.reancy');
      $tbl_typ = "Hospital";
      $tbl_cls = "Government";
      $data = DB::select('SELECT tbl_colind, tbl_colnm, tbl_stl FROM radoholrstbl_hdr WHERE tbl_typ = ? AND tbl_cls = ?', [$tbl_typ, $tbl_cls]);
      $data1 = DB::select('SELECT tbl_rowind, tbl_colind, tbl_stl, tbl_colcont FROM radoholrstbl_ctnt WHERE tbl_typ = ? AND tbl_cls = ?', [$tbl_typ, $tbl_cls]);
      return view('template.reancy', ['hdr' => $data, 'cnt' => $data1]);
   }
   public function reancy(Request $request){
      $tbl_typ = "Hospital";
      $tbl_cls = "Government";
      $data = DB::select('SELECT tbl_colind, tbl_colnm FROM radoholrstbl_hdr WHERE tbl_typ = ? AND tbl_cls = ?', [$tbl_typ, $tbl_cls]);
      return view('template.reancy', ['hdr' => $data]);
   }
}
