<div style="background: url('/color.png') no-repeat;
    background-size: 100% auto; box-shadow: 0px 2px 4px rgba(0,0,0,0.2);">
<div class="container" >
  <div class="row">
    <div class="col-md-8">
      <img src="/DOH.png">
    </div>
    <div class="col-md-4"></div>
  </div>
</div>
</div>
