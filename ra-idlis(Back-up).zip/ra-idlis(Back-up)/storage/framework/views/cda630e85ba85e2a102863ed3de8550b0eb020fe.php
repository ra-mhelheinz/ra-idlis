<!DOCTYPE html>
<html lang="en">
<head>
	
</head>
<body>
	    <!-- Navigation -->
<?php echo $__env->make('template.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Content -->
	<div class="jumbotron" style="margin-bottom: 0!important;">
		<div class="container">
			<!-- <div class="row">
			  	<div class="col-8">
			  		
			  	</div>
			  	<div class="col-4">
			  		
			  	</div>
			</div>
			<hr> -->
			<div class="table-responsive">
				<table class="table table-borderless">
					<thead>
						<tr>
							<td width="80%">
								<h2>ABC Hospital</h2>
								<h4>Rizal St. Manila</h4>
							</td>
							<td width="5%"></td>
							<td width="15%">
								<center><h4>DOH</h4>
									<h4>Verification</h4></center>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td >
								<font>
									1. Acknowledgement (Notarized)
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- //// -->
						<tr>
							<td >
								<font>
									2. List of Personnel
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									3. List of Equipment/Instrument
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									4. List of Ancillary Services
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									5. Application Form (for Medical X-ray)
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									6. Application Form (Hospital Pharmacy)
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									7. Geographic Form (Location Map)
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									8. Photographs of exterior & interior of facility
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									9. Annual Statistical Reports
								</font>
							</td>
							<td>
								<center>
									<button type="button" class="btn btn-primary">
										<i class="fa fa-eye" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<hr>
			<form class="text-center">
				<label>Recommended for Inspection?</label>
				<button>Yes</button>
				<button>No</button><br>
				<label>Proposed Date of Inspection:</label>
				<input type="date" name="">
			</form>
		</div>	
	</div>
	<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script type="text/javascript" src="/js/app.js"></script>
</body>
</html>
<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>