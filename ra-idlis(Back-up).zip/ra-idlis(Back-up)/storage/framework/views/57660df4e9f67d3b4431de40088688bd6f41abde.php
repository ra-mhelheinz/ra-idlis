<div class="jumbotron">
	SAMPLE
</div>