 <?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php if(session()->exists('current_employee')): ?>
    <?php $__currentLoopData = session()->get('current_employee'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <script type="text/javascript">
        var type = "<?php echo e($test->position); ?>";
        if (type != "Head") {
          window.location.href = "<?php echo e(asset('/dashboard')); ?>";
        }
      </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php else: ?>
  <script>window.location.href = "<?php echo e(asset('/employeelogin')); ?>";</script>
 <?php endif; ?>
 <?php if(session()->exists('current_user')): ?>
  <script type="text/javascript">
    window.location.href = "<?php echo e(asset('/home')); ?>";
  </script>
<?php endif; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/ra-idlis/public/css/dashboard.css')); ?>">
        <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Head, HFSRB</a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="<?php echo e(asset('/logout2')); ?>" onclick="event.preventDefault();document.getElementById('employeeLogout').submit();">Sign out</a>
          <form id="employeeLogout" action="<?php echo e(asset('/logout2')); ?>" method="POST" hidden>
            <?php echo csrf_field(); ?>
          </form>
        </li>
      </ul>
    </nav>
      <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Dashboard
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Licensing Officer</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="#"  data-toggle="modal" data-target="#myModal">
                  <span data-feather="file-text"></span>
                  Add Account
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(asset('headashboard/loaccount')); ?>" >
                  <span data-feather="file-text"></span>
                 View LO Accounts
                </a>
              </li>
            </ul>
          </div>
        </nav>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Dashboard</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
              <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
              </button>
            </div>
          </div>
          <h2>Licensing Process Status (Region NCR)</h2>
          <div class="table-responsive">
            <table class="table" style="overflow-x: scroll;">
              <thead>
                <tr>
                  <th>Application #</th>
                  <th>Name of Facility</th>
                  <th>Status of Application</th>
                  <th>Evaluate</th>
                  <th>Order of Payment</th>
                  <th>Upload OR Copy</th>
                  <th>Recommended for Inspection</th>
                  <th>Date of inspection</th>
                  <th>Issuance Status: Approval/Disapproval</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>ABC Hospital</td>
                  <td>Initial</td>
                  <td><a href="<?php echo e(asset('dashboard/evaluate')); ?>">Evaluate</a></td>
                  <td></td>
                   <td></td>
                    <td><a href="<?php echo e(asset('dashboard/inspection')); ?>" style="color:green;">Yes</a></td>
                    <td>05/05/2018</td>
                    <td><a href="<?php echo e(asset('issuance')); ?>" style="color:green;">Approved </a></td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>C.D Clinic</td>
                  <td>Renewal</td>
                  <td><a href="<?php echo e(asset('dashboard/evaluate')); ?>">Evaluate</a></td>
                  <td></td>
                  <td></td>
                  <td style="color:red;">No</td>
                   <td></td>
                   <td style="color:red;">Disapproved</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Hospital H</td>
                  <td>Initial</td>
                  <td><a href="<?php echo e(asset('dashboard/evaluate')); ?>">Evaluate</a></td>
                  <td></td>
                  <td></td>
                   <td style="color:red;">No</td>
                    <td></td>
                     <td style="color:red;">Disapproved</td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>libero</td>
                  <td>Renewal</td>
                  <td><a href="<?php echo e(asset('dashboard/evaluate')); ?>">Evaluate</a></td>
                  <td></td>
                  <td></td>
                   <td style="color:red;">No</td>
                    <td></td>
                     <td style="color:red;">Disapproved</td>

                </tr>
                <tr>
                  <td>5</td>
                  <td>dapibus</td>
                  <td>Initial</td>
                  <td><a href="<?php echo e(asset('dashboard/evaluate')); ?>">Evaluate</a></td>
                  <td></td>
                  <td></td>
                   <td style="color:red;">No</td>
                    <td></td>
                     <td style="color:red;">Disapproved</td>
                </tr>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="border-radius: 0px;border: none;">
      <div class="modal-body text-justify" style=" background-color: #272b30;
    color: white;">
        <h5 class="modal-title text-center"><strong>Licensing Officer (LO) Registration</strong></h5>
        <hr>
        <div class="container">
	        <form class="row" action="<?php echo e(asset('headashboard/addLO')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

	        	<div class="col-sm-4">First Name:</div>
	        	<div class="col-sm-8">
	        	<input type="text" name="fname" class="form-control"  style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4" >Middle Name:</div>
	        	<div class="col-sm-8">
	        	<input type="text" name="mname" class="form-control" style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4"">Last Name:</div>
	        	<div class="col-sm-8">
	        	<input type="text" name="lname" class="form-control"  style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4"">Position:</div>
	        	<div class="col-sm-8">
	        	<select class="form-control" name="pos" id="pos_val" style="margin:0 0 .8em 0;" onchange="getOthers();">
            <option hidden></option>  
            <option>Licensing Officer I</option>  
            <option>Licensing Officer II</option>  
            <option>Licesing Officer III</option> 
            <option>Medical Officer V</option> 
            <option>Medical Officer IV</option> 
            <option>Medical Officer III</option> 
            <option>Dentist IV</option> 
            <option>Dentist III</option> 
            <option>Dentist II</option> 
            <option>Others</option>
            </select>
	        	</div>
            <div class="col-sm-4 SH_Others"  style="display:none;"></div>  
            <div class="col-sm-8 SH_Others" style="display: none">
                <input type="name" name="OthersInput" id="OthersInputted" placeholder="Others" class="form-control" style="margin:0 0 .8em 0;" >
            </div>
	        	<div class="col-sm-4"">Email Address:</div>
	        	<div class="col-sm-8">
	        	<input type="email" name="email" class="form-control"  style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4"">Contact No:</div>
	        	<div class="col-sm-4">
	        	<input type="text" name="t_num" class="form-control" placeholder="Tel No." style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4">
	        	<input type="text" name="c_num" class="form-control" placeholder="Cel No." style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4">
	        		Username:
	        	</div>
	        	<div class="col-sm-8">
	        		<input type="text" name="uname" class="form-control" style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-4">
	        		Password:
	        	</div>
	        	<div class="col-sm-8">
	        		<input type="password" name="pass" class="form-control" style="margin:0 0 .8em 0;">
	        	</div>
	        	<div class="col-sm-12">
	        		<button type="submit" class="btn btn-outline-success form-control" style="border-radius:0;"><span class="fa fa-sign-up"></span>Add New Licensing Officer</button>
	        	</div> 
	        </form>
	     </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    function getOthers(){
      var selectedId =  $('#pos_val').children(':selected').val();
      if (selectedId == "Others") {
        $('.SH_Others').show();
      } else {
         $('.SH_Others').hide();
      }
    }
</script>