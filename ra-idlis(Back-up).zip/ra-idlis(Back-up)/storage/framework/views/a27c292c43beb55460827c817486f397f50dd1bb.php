<div class="fixed-bottom" style="background:transparent;width:30%;float: left;margin-left: 72%;border-radius: 5px 5px 0 0">
	<div style="padding: 3px;">
		<img width="100%" src="<?php echo e(asset('/ra-idlis/public/img/slogan.png')); ?>">
	</div>
</div>
<footer style="background: url('ra-idlis/public/color.png') no-repeat;
    background-size: 100% auto; box-shadow: 0px 2px 4px rgba(0,0,0,0.2);padding:2% 2% 2% 2%;">
      <div class="container">
        <p class="m-0 text-center">DOH Licensing and Regulatory System</p>
      </div>
      <!-- /.container -->
</footer>

