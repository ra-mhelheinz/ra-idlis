
<?php echo $__env->make('template.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = Session::get('current_user'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="jumbotron container" style="margin-top: 2em;box-shadow: 10px 10px 15px rgba(73, 78, 92, 0.1);background-color: #fff">
		<div class="container">
			<div class="table-responsive">
				<table class="table table-borderless">
					<thead>
						<tr>
							<td width="80%">
								<h2><?php echo e($test->facility_name); ?></h2>
								<h4><?php echo e($test->street); ?>, <?php echo e($test->brgy); ?>, <?php echo e($test->city_mun); ?>, <?php echo e($test->zip); ?> <?php echo e($test->province); ?> - <?php echo e($test->region); ?></h4>
							</td>
							<td>
								<center><h4>DOH Evaluation Status</h4></center>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td >
								<font>
									1. Acknowledgement (Notarized)
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- //// -->
						<tr>
							<td >
								<font>
									2. List of Personnel
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									3. List of Equipment/Instrument
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									4. List of Ancillary Services
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									5. Application Form (for Medical X-ray)
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									6. Application Form (Hospital Pharmacy)
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									7. Geographic Form (Location Map)
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-success">
										<i class="fa fa-check" aria-hidden="true"></i>
									</button>
								</center>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									8. Photographs of exterior & interior of facility
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
							<td>
									<a href="" data-toggle="modal" data-target="#Modal1"><button class="btn btn-outline-primary">View Details</button></a>

							</td>
								<td>
									<a href="" ><button class="btn btn-primary"><span class="fa fa-upload"></span>&nbsp;Re-upload</button></a>
							</td>
						</tr>
						<!-- /// -->
						<tr>
							<td >
								<font>
									9. Annual Statistical Reports
								</font>
							</td>
							<td>
								<center>
									
									<button type="button" class="btn btn-danger">
										<i class="fa fa-times" aria-hidden="true"></i>
									</button>
								</center>
							</td>
								<td>
									<a  data-toggle="modal" data-target="#Modal1" ><button class="btn btn-outline-primary">View Details</button></a>
							</td>
								<td>
									<a href=""><button class="btn btn-primary"><span class="fa fa-upload"></span>&nbsp;Re-upload</button></a>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<hr>
				<div class="row">
					<div class="col-sm-6" >
							<label>Recommended for Inspection:</label>
							<!-- data-toggle="modal" data-target="#exampleModalCenter" -->
							<strong><label style="color:red;">&nbsp;No</label></strong>
					</div>	
					<div class="col-sm-6">
						<span>
							<label class="form-inline">Proposed Date of Inspection:
							<strong><label style="color:red" >&nbsp;None</label></strong>
						</span>
					</div>		
				</div>
		</div>	
	</div>
<div class="modal fade" id="Modal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content"  style= "border-radius: none;">
      <div class="modal-body">
	        <div class="alert alert-danger" role="alert">
				<p class="alert-heading"><i class="far fa-sticky-note"></i> Note:</p>
				<p>&nbsp;- Lacking of ....</p>
			</div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>