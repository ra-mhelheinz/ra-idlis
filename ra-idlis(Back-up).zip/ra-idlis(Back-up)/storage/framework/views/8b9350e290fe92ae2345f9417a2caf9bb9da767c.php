<header>
	<div class="jumbotron">
		SAMPLE
	</div>
</header>