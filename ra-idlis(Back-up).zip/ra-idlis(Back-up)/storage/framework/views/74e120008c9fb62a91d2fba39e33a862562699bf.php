<?php 
		try {
				$handler = new PDO('mysql:host=localhost;dbname=rightapp_doholrs', 'rightapp_DOHtask', 'Rightech777');
				$handler->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);
		
			} 
			catch (Exception $e) {
				echo "Error";
				die();
			}
?>
<?php if(session()->exists('current_employee')): ?>
    <?php $__currentLoopData = session()->get('current_employee'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <script type="text/javascript">
        var type = "<?php echo e($test->position); ?>";
        if (type == "Head") {
          window.location.href = "<?php echo e(asset('/headashboard')); ?>";
        } else {
        	window.location.href = "<?php echo e(asset('/dashboard')); ?>";
        }
      </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(session()->exists('current_user')): ?>
	<script type="text/javascript">
		window.location.href = "<?php echo e(asset('/home')); ?>";
	</script>
<?php endif; ?>
<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<header>
	<div class="jumbotron" style="padding: 0 !important;border-radius:0;background-color: #fff !important;margin-bottom: 0;">
		<div class="container">
		<div class="row">
			<div class="col-md-6" style="margin: 3em auto">
				<h3>DOH Licensing Process</h3>
				<br>
				<div class="row">
					<div class="col-sm-6">
						<h4><i class="fa fa-registered"></i>&nbsp;<strong>Step 1.</strong> Registration</h4>
						<p>Sign-up for your health facility. Get your username and password.</p>
						<br>
						<h4><i class="fa fa-check"></i>&nbsp;<strong>Step 3.</strong> Evaluation</h4>
						<p>DOH will evaluate your submitted documents and notify your schedule of inspection.</p>
						<br>
						<h4><i class="fa fa-print"></i>&nbsp;<strong>Step 5.</strong> Issuance</h4>
						<p>You can now print your application online.</p>
					</div>
					<div class="col-sm-6">
						<h4><i class="fa fa-address-book"></i>&nbsp;<strong>Step 2.</strong> Apply</h4>
						<p>Fill-in application form and submit requirements online.</p>
						<br>
						<h4><i class="fa fa-search"></i>&nbsp;<strong>Step 4.</strong> Inspection</h4>
						<p>DOH will conduct inspection and notify the status of your application.</p>
					</div>
				</div>
			</div>
			<div class="col-sm-1">
			</div>
			<div class="col-md-5">
 				<div class="form-wrapss" style="width: 420px !important;">
 				<div class="text-center" style="background-color: #e6e7e8;">
					<h3 style="padding: 20px;">Login</h3>
				</div>
 					<div class="tabss-content">
 

			<div id="login-tab-content" class="active">
				<form class="login-form" action="<?php echo e(asset('/')); ?>" method="post" data-parsley-validate="">
					<?php echo e(csrf_field()); ?>

					<?php if(session()->has('client_login')): ?>
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
					  <strong><i class="fas fa-exclamation"></i></strong> <?php echo e(session()->get('client_login')); ?>

					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					    <span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php endif; ?>
					<?php if(session()->has('reg_notif_success')): ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
					  <strong><i class="fas fa-exclamation"></i></strong> <?php echo e(session()->get('reg_notif_success')); ?>

					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					    <span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php endif; ?>
					<?php if(session()->has('logout_notif')): ?>
					<div class="alert alert-info alert-dismissible fade show" role="alert">
					  <strong><i class="fas fa-exclamation"></i></strong> <?php echo e(session()->get('logout_notif')); ?>

					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					    <span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php endif; ?>
					<input type="text" class="input form-control" name="uname" autocomplete="on" placeholder="Username" value="<?php echo e(old('uname')); ?>" required="" data-parsley-type="alphanum">
					<input type="password" class="input form-control" name="pass" autocomplete="on" placeholder="Password" required="">
					<input type="checkbox" class="checkbox 	" id="remember_me">
					<label for="remember_me">Remember me</label>

					<button type="submit" name="button" class="button" value="Login">Login</button>
				</form><!--.login-form-->
				<div class="help-text">
					<p>Not a member yet?<a href="<?php echo e(asset('register')); ?>">&nbsp;Register now</a></p>
					<p><a href="<?php echo e(asset('employeelogin')); ?>">DOH employee login</a></p>
				</div><!--.help-text-->
			</div><!--.login-tab-content-->
		</div><!--.tabs-content-->
	</div><!--.form-wrap-->
			</div>
		</div>
	</div>
</div>
</header>


<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
	jQuery(document).ready(function($) {
	tab = $('.tabss h3 a');

	tab.on('click', function(event) {
		event.preventDefault();
		tab.removeClass('active');
		$(this).addClass('active');

		tab_content = $(this).attr('href');
		$('div[id$="tab-content"]').removeClass('active');
		$(tab_content).addClass('active');
	});
});
</script>
<script type="text/javascript">
						function region() {
							if(document.getElementById('regionSelector').selectedIndex < 1) {

							} else {
								// document.getElementById('regionSelector').options[document.getElementById('regionSelector').selectedIndex].id
								hideUnhideRegion(document.getElementById('regionSelector').selectedIndex);

							}
						}
						function hideUnhideRegion(region) {
							var arr = {0:"Choose Region...", 
										1:"Metro Manila", // NCR
										2:"Abra, Apayao, Benguet, Ifugao, Kalinga, Mountain Province", // CAR
										3:"Ilocos Norte, Ilocos Sur, La Union, Pangasinan", // Region 1
										4:"Batanes, Cagayan, Isabela, Nueva Vizcaya, Quirino", // Region 2
										5:"Aurora, Bataan, Bulacan, Nueva Ecija, Pampanga, Tarlac, Zambales", // Region 3
										6:"Batangas, Cavite, Laguna, Quezon, Rizal", // Region 4-A
										7:"Marinduque, Occidental Mindoro, Oriental Mindoro, Palawan, Romblon", // Region 4-B
										8:"Albay, Camarines Norte, Camarines Sur, Catanduanes, Masbate, Sorsogon", // Region 5
										9:"Aklan, Antique, Capiz, Iloilo, Guimaras, Negros Oriental", // Region 6
										10:"Bohol, Cebu, Negros Occidental, Siquijor", // Region 7
										11:"Biliran, Eastern Samar, Leyte, Nothern Samar, Samar (Western Samar), Southern Leyte", // Region 8
										12:"Zamboanga del Norte, Zamboanga del Sur, Zamboanga Sibugay", // Region 9
										13:"Bukidnon, Camiguin, Lanao del Norte, Misamis Occidental, Misamis Oriental", // Region 10
										14:"Compostela Valley, Davao del Norte, Davao del Sur, Davao Oriental, Davao Occidental", // Region 11
										15:"Cotabato (North Cotabato), South Cotabato, Sultan Kudarat, Sarangani", //Region 12
										16:"Agusan del Norte, Agusan del Sur, Surigao del Norte, Surigao del Sur, Dinagat Islands",
										17:"Basilan, Lanao del Sur, Maguindanao, Sulu, Tawi-Tawi"};
							if(region < 1 || region === null) {
								document.getElementById('anotherRegionSelector').innerHTML = '<option>'+arr[0]+'</option>'
							} else {
								var anotherArr = arr[region].split(", ");
								document.getElementById('anotherRegionSelector').innerHTML = '';
								for(var i = 0; i < anotherArr.length; i++) {
									document.getElementById('anotherRegionSelector').innerHTML += '<option>'+anotherArr[i]+'</option>';
								}
							}
						}
					</script>