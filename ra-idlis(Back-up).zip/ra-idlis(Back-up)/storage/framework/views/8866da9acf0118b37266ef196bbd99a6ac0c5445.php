<!DOCTYPE html>
<html lang="en">
<head>
	
	
</head>
<body>
	<?php echo $__env->make('template.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="jumbotron" style="margin-bottom: 0!important;">
		<div class="container">
			<h2>Apply</h2>
			<div class="container row">
				<div class="col row">
					<h4>Name of Hospital : </h4>
					&nbsp;&nbsp;&nbsp;&nbsp;
					<h3>ABC Hospital</h3>
				</div>
			</div>
			<hr>
			<div class="container">
			  <div class="row">
			    <div class="col-sm-6">
			      <font>Type of Health Facility :</font>
			      <span style="float: right;">
			      	<div class="dropdown">
					  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					    Dropdown button
					  </button>
					  <div class="dropdown-menu">
					    <a class="dropdown-item" href="#">Link 1</a>
					    <a class="dropdown-item" href="#">Link 2</a>
					    <a class="dropdown-item" href="#">Link 3</a>
					  </div>
					</div>
			      </span>
			    </div>
			    <div class="col-sm-6">
			      <font>Services :</font>
			      <span style="float: right;">
			      	<div class="dropdown">
					  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					    Dropdown button
					  </button>
					  <div class="dropdown-menu">
					    <a class="dropdown-item" href="#">Link 1</a>
					    <a class="dropdown-item" href="#">Link 2</a>
					    <a class="dropdown-item" href="#">Link 3</a>
					  </div>
					</div>
			      </span>
			    </div>
			  </div>
			</div>
			<br>
			<div class="container">
			  <div class="row">
			    <div class="col-sm-6">
			      <font>Classification as to Ownership :</font>
			      <span style="float: right;">
			      	<div class="dropdown">
					  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					    Dropdown button
					  </button>
					  <div class="dropdown-menu">
					    <a class="dropdown-item" href="#">Link 1</a>
					    <a class="dropdown-item" href="#">Link 2</a>
					    <a class="dropdown-item" href="#">Link 3</a>
					  </div>
					</div>
			      </span>
			    </div>
			    <div class="col-sm-6">
			      <font>Status of Application :</font>
			      <span style="float: right;">
			      	<div class="dropdown">
					  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					    Dropdown button
					  </button>
					  <div class="dropdown-menu">
					    <a class="dropdown-item" href="#">Link 1</a>
					    <a class="dropdown-item" href="#">Link 2</a>
					    <a class="dropdown-item" href="#">Link 3</a>
					  </div>
					</div>
			      </span>
			    </div>
			  </div>
			</div>
			<br>
			<div class="container">
			  <div class="row">
			    <div class="col-sm-6">
			      <font>Authorized Bed Capacity :</font>
			      <span style="float: right;">
			      	<input type="text" name="" placeholder="Number of Beds">
			      </span>
			    </div>
			  </div>
			</div>
		<br>
		<hr>
		<div class="container">
			<center><h5>Attachments</h5></center>
			<ul class="list-group">
			  <li class="list-group-item">Acknowledgement (Notarized) 
			  	<span style="float:right">
			  		<button type="button" class="btn btn-primary">Upload</button>
			  	</span>
			  </li>
			  <li class="list-group-item">List of Personnel
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  	</span>
			  </li>
			  <li class="list-group-item">List of Equipment/Instrument
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  </span>
			  </li>
			  <li class="list-group-item">List of Ancillary Services
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  </span>
			  </li>
			  <li class="list-group-item">Application Form (for Medical X-ray)
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  </span>
			  </li>
			  <li class="list-group-item">Application Form (Hospital Pharmacy)
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  </span>
			  </li>
			  <li class="list-group-item">Geographic Form (Location Map)
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  </span>
			  </li>
			  <li class="list-group-item">Photographs of exterior & interior of facility
				  <span style="float:right">
				  		<button type="button" class="btn btn-primary">Upload</button>
				  </span>
			  </li>
			</ul>
		</div>
	</div>
</div>
	<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script type="text/javascript" src="/js/app.js"></script>
</body>
</html>
<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>