<header>
	<div class="jumbotron" style="padding: 0 !important;border-radius:0;background-color: #fff !important;margin-bottom: 0;">
		<div class="container">
		<div class="row">
			<div class="col-md-6" style="margin: 3em auto">
				<h3>DOH Licensing Process</h3>
				<br>
				<div class="row">
					<div class="col-sm-6">
						<h4><i class="fa fa-registered"></i> Registration</h4>
						<p>Sign-up for your health facility. Get your username and password.</p>
						<br>
						<h4><i class="fa fa-check"></i> Verification</h4>
						<p>DOH will verify your submitted documents and notify your schedule of inspection.</p>
						<br>
						<h4><i class="fa fa-print"></i> Issuance</h4>
						<p>You can now print your application online.</p>
					</div>
					<div class="col-sm-6">
						<h4><i class="fa fa-address-book"></i> Apply</h4>
						<p>Fill-in application form and submit requirements online.</p>
						<br>
						<h4><i class="fa fa-search"></i> Inspection</h4>
						<p>DOH will conduct inspection and notify the status of your application.</p>
					</div>
				</div>
			</div>
			<div class="col-md-6">
 				<div class="form-wrapss">
		<div class="tabss">
			<h3 class="signup-tab"><a class="active" href="#signup-tab-content" style="text-decoration: none;cursor:pointer;">Sign Up</a></h3>
			<h3 class="login-tab"><a href="#login-tab-content" style="text-decoration: none;cursor:pointer;">Login</a></h3>
		</div><!--.tabs-->

		<div class="tabss-content">
			<div id="signup-tab-content" class="active">
				<form class="signup-form form-inline" action="" method="post">
					<div class="row">
						<div class="col-sm-6">
					<input type="email" class="input form-control" id="user_email" autocomplete="off" placeholder="Name of Facility">
					</div>
					<div class="col-sm-6">
					<input type="text" class="input form-control" id="user_name" autocomplete="off" placeholder="Address">
					</div>
					<div class="col-sm-12">
					<input type="password" class="input form-control" id="user_pass" autocomplete="off" placeholder="Authorized Signature">
				</div>
				<div class="col-sm-6">
					<input type="email" class="input form-control" id="user_email" autocomplete="off" placeholder="Username">
				</div>
				<div class="col-sm-6">
					<input type="text" class="input form-control" id="user_name" autocomplete="off" placeholder="Password">
				</div>
				<div class="col-sm-12">
					<input type="password" class="input form-control" id="user_pass" autocomplete="off" placeholder="Retype Password">
				</div>
				<div class="col-sm-12">
					<input type="password" class="input form-control" id="user_pass" autocomplete="off" placeholder="Email Address">
				</div>
				<div class="col-sm-12">
					<input type="password" class="input form-control" id="user_pass" autocomplete="off" placeholder="Contact Person">
				</div>
					</div>
					<input type="submit" class="button" value="Sign Up">
				</form><!--.login-form-->
				<div class="help-text">
					<p>By signing up, you agree to our</p>
					<p><a href="#">Terms of service</a></p>
				</div><!--.help-text-->
			</div><!--.signup-tab-content-->

			<div id="login-tab-content">
				<form class="login-form" action="" method="post">
					<input type="text" class="input form-control" id="user_login" autocomplete="off" placeholder="Username">
					<input type="password" class="input form-control" id="user_pass" autocomplete="off" placeholder="Password">
					<input type="checkbox" class="checkbox 	" id="remember_me">
					<label for="remember_me">Remember me</label>

					<input type="submit" class="button" value="Login">
				</form><!--.login-form-->
				<div class="help-text">
					<p><a href="#">Forget your password?</a></p>
				</div><!--.help-text-->
			</div><!--.login-tab-content-->
		</div><!--.tabs-content-->
	</div><!--.form-wrap-->
			</div>
		</div>
	</div>
</div>
</header>
<script type="text/javascript">
	jQuery(document).ready(function($) {
	tab = $('.tabss h3 a');

	tab.on('click', function(event) {
		event.preventDefault();
		tab.removeClass('active');
		$(this).addClass('active');

		tab_content = $(this).attr('href');
		$('div[id$="tab-content"]').removeClass('active');
		$(tab_content).addClass('active');
	});
});
</script>