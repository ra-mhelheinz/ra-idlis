<!DOCTYPE html>
<html lang="en">
<head>
	
</head>
<body>
	<?php echo $__env->make('template.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="jumbotron" style="margin-bottom: 0!important;">
		<div class="container">
			<h2>ABC Hospital. Rizal St., Manila</h2>
			<hr>
			<div class="container align-items-center">
				<font size="24px">Assessment Tool</font>
				<span style="float:right">
					<div class="btn-group">
					  <button type="button" class="btn btn-primary active">Part I</button>
					  <button type="button" class="btn btn-primary">Part II</button>
					  <button type="button" class="btn btn-primary">Part III</button>
					</div>
				</span>
				<hr>
			</div>
			<div class="container">
				<h3>
					I. The hospital appoints and allocates personnel who are suitably qualified, skilled and/or experienced to provide service and meet patient needs. 
				</h3>
			</div>
			<hr>
			<div class="container">
				<div class="row">
					<div class="col-8">
							<h5 style="text-align: justify;">
								&nbsp;&nbsp;&nbsp;1.&nbsp;All personnel are qualified, skilled and/or experienced to assume the responsibility, authority, accountability, and functions of their respective positions. 
							</h5>
					</div>
					<div class="col-2">
						<center>
							<button type="button" class="btn btn-success">
								<i class="fa fa-check" aria-hidden="true"></i>
							</button>
							<button type="button" class="btn btn-danger">
								<i class="fa fa-times" aria-hidden="true"></i>
								</button>
						</center>
					</div>
					<div class="col-2">
						<font>Remarks</font>
						<textarea></textarea>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-8">
							<h5 style="text-align: justify;">
								&nbsp;&nbsp;&nbsp;2.&nbsp;Professional qualifications are validated,  including evidence of professional registration/ license, where applicable, prior to employment. 
							</h5>
					</div>
					<div class="col-2">
						<center>
							<button type="button" class="btn btn-success">
								<i class="fa fa-check" aria-hidden="true"></i>
							</button>
							<button type="button" class="btn btn-danger">
								<i class="fa fa-times" aria-hidden="true"></i>
								</button>
						</center>
					</div>
					<div class="col-2">
						<font>Remarks</font>
						<textarea></textarea>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-8">
							<h5 style="text-align: justify;">
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.&nbsp;&nbsp;&nbsp;All doctors, nurses and pharmacists have updated licenses.
							</h5>
					</div>
					<div class="col-2">
						<center>
							<button type="button" class="btn btn-success">
								<i class="fa fa-check" aria-hidden="true"></i>
							</button>
							<button type="button" class="btn btn-danger">
								<i class="fa fa-times" aria-hidden="true"></i>
								</button>
						</center>
					</div>
					<div class="col-2">
						<font>Remarks</font>
						<textarea></textarea>
					</div>
				</div>
			</div>
	</div>
</div>
<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script type="text/javascript" src="/js/app.js"></script>
	
</body>
</html>
<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>