<footer style="background: url('/color.png') no-repeat;
    background-size: 100% auto; box-shadow: 0px 2px 4px rgba(0,0,0,0.2);padding:2% 2% 2% 2%;">
      <div class="container">
        <p class="m-0 text-center">DOH Licensing and Regulatory System</p>
      </div>
      <!-- /.container -->
  </footer>

