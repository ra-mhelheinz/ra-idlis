<!DOCTYPE html>
<html lang="en">
  <head>
    
  </head>
  <style type="text/css">
    .card{
      height: 100%;
    }
      .carousel-inner img {
      width: 100%;
      height: 100%;
  }
  </style>
  <body>
    <div style="background: url('/color.png') no-repeat;
    background-size: 100% auto; box-shadow: 0px 2px 4px rgba(0,0,0,0.2);">
<div class="container" >
  <div class="row">
    <div class="col-md-8">
      <img src="/DOH.png">
    </div>
    <div class="col-md-4"></div>
  </div>
</div>
</div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
        <!-- Page Content -->

<div class="container-fluid">
      <!-- Jumbotron Header -->

      <header class="my-4" style="margin-top:0 !important;">
       <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="/caro.jpg" alt="Los Angeles"  style="height:400px;">
      <div class="carousel-caption">
        <h3>Los Angeles</h3>
        <p>We had such a great time in LA!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="/caro2.jpg" alt="Chicago" style="height:400px;">
      <div class="carousel-caption">
        <h3>Chicago</h3>
        <p>Thank you, Chicago!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="/caro3.jpg" alt="New York" style="height:400px;">
      <div class="carousel-caption">
        <h3>New York</h3>
        <p>We love the Big Apple!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

      </header>
</div>
      <!-- Page Features -->
    <div class="container">
      <div class="row text-center">

        <div class="col-lg-4 col-md-6 mb-4">
          <div class="card">
            <div class="container" style="padding: 10px;">
            <img class="card-img-top" src="/register.png" alt="" height="250"></div>
            <div class="card-body">
              <h4 class="card-title">Register</h4>
              <p class="card-text">Sign-up for your health facility. Get your username and password.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
          <div class="card">
             <div class="container" style="padding: 10px;">
            <img class="card-img-top" src="/apply.png" alt="" height="250">
              </div>
            <div class="card-body">
              <h4 class="card-title">Apply</h4>
              <p class="card-text">>DOH will verify your submitted documents and notify your schedule of inspection.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
          <div class="card">
             <div class="container" style="padding: 10px;">
            <img class="card-img-top" src="/Verify.png" alt="" height="250">
              </div>
            <div class="card-body">
              <h4 class="card-title">Verify</h4>
              <p class="card-text">Fill-in application form and submit requirements online.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
          </div>
        </div>

          <div class="col-lg-4 col-md-6 mb-4 offset-2">
          <div class="card">
             <div class="container" style="padding: 10px;">
            <img class="card-img-top" src="/inspec.png" alt="" height="250">
              </div>
            <div class="card-body">
              <h4 class="card-title">Inspection</h4>
              <p class="card-text">DOH will conduct inspection and notify the status of your application.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
          <div class="card">
             <div class="container" style="padding: 10px;">
            <img class="card-img-top" src="/print.jpg" alt="" height="250">
              </div>
            <div class="card-body">
              <h4 class="card-title">Issuance</h4>
              <p class="card-text">You can now print your application online.</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
   

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>

<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>